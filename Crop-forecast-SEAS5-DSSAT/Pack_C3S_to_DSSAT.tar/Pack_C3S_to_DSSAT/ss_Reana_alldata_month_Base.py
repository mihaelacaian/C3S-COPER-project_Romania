#
# year = 2026
# month = 1

area = "49.5/18/44.5/30"
grid = "0.25/0.25"

#
from ecmwfapi import ECMWFService
from datetime import datetime, timedelta

server = ECMWFService("mars")

# Definim cele două tipuri de cereri într-o listă de dicționare
configs = [
    {
        "name": "output0+12",
        "stream": "oper",
        "time": ["00:00:00", "12:00:00"],
        "param": "169.128/167.128/228.128"
    },
    {
        "name": "output6+18",
        "stream": "scda",
        "time": ["06:00:00", "18:00:00"],
        "param": "169.128/167.128/228.128"
    }
]

# Generăm data de start și numărul de zile pentru Ianuarie (31 zile)
start_date = datetime(year, month, 1)

for i in range(31):
    current_date = (start_date + timedelta(days=i)).strftime("%Y%m%d")
    
    for cfg in configs:
        request = {
            "class": "od",
            "stream": cfg["stream"],
            "type": "fc",
            "expver": "1",
            "method": "1",
            "levtype": "sfc",
            "date": current_date,
            "area": area,
            "grid": grid,
            "time": cfg["time"],
            "param": cfg["param"],
            "step": "1/2/3/4/5/6",
            "packing": "simple",
            "format": "grib2"
        }
        
        target_file = f"{cfg['name']}_{current_date}_oper_1hfc.grib"
        
        print(f"Se descarcă: {target_file}...")
        try:
            server.execute(request, target_file)
        except Exception as e:
            print(f"Eroare la data {current_date} pentru {cfg['stream']}: {e}")

print("Proces finalizat pentru toată luna!")
