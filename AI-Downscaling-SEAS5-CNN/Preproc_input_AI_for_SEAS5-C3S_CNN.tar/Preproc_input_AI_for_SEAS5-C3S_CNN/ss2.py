
import h5py
with h5py.File('./hres_2017.hdf5', 'r') as f:
    if 'static_variables' in f:
        print("Variabile statice in ERA5:", list(f['static_variables'].keys()))
    else:
        print("Grupul static_variables LIPSESTE din ERA5!")
