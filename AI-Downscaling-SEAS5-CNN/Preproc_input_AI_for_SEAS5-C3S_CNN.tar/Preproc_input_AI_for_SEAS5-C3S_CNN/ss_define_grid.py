

import h5py
import numpy as np

def update_h5_geometry(file_path, lats_range, lons_range):
    with h5py.File(file_path, 'a') as f:
        # 1. Obținem dimensiunea necesară din zOro (deja existent în fișier)
        if 'static_variables/zOro' not in f:
            print(f"Eroare: zOro lipsește din {file_path}. Nu pot determina forma grilei.")
            return
        
        target_shape = f['static_variables/zOro'].shape  # Forma (latitudini, longitudini)
        n_lat, n_lon = target_shape
        
        # 2. Generăm vectorii de coordonate liniari
        # ERA5 și HRES folosesc de obicei ordinea Nord -> Sud pentru latitudini
        lat_vec = np.linspace(lats_range[0], lats_range[1], n_lat) 
        lon_vec = np.linspace(lons_range[0], lons_range[1], n_lon)
        
        # 3. Creăm matricele 2D (Meshgrid)
        # indexing='ij' asigură că prima dimensiune este latitudinea, a doua longitudinea
        lon_2d, lat_2d = np.meshgrid(lon_vec, lat_vec)
        
        # 4. Inserăm sau actualizăm în grupul static_variables
        static = f['static_variables']
        datasets_to_add = [
            ('lons', lon_2d), 
            ('lats', lat_2d), 
            ('padding_mask', np.ones(target_shape)) # Mască de 1-uri cerută de cod
        ]
        
        for name, data in datasets_to_add:
            if name in static:
                del static[name]  # Ștergem versiunea veche pentru a evita erori de dimensiune
            static.create_dataset(name, data=data.astype(np.float32))
            print(f"Succes: Adăugat {name} ({data.shape}) în {file_path}")

# Definirea intervalelor tale (Nord-Sud, Vest-Est)
lats_interval = (47.0, 43.4) 
lons_interval = (23.0, 26.6)
# Aplică modificările pe ambele fișiere
#
update_h5_geometry('./hres_3y.hdf5', lats_interval, lons_interval)
