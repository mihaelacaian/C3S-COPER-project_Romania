
import h5py
import xarray as xr
import numpy as np
import pandas as pd

# 1. Deschidem fișierul
#ds = xr.open_dataset('all_LR_2016_cal_3d2d.nc_unit')
#ds = xr.open_dataset('all_LR_2016-2018_cal_3d2d.nc_unit')
#ds = xr.open_dataset('all_LR_3y.nc_unit')
ds = xr.open_dataset('merged_3d+2d_3y_lowres.nc')

# 2. Definim maparea (TREBUIE să fie înainte de utilizare)
# Asigură-te că numele din dreapta ('u10', etc.) sunt cele din NetCDF-ul tău
mapping = {
    'windU': 'windU', 
    'windV': 'windV', 
    'blh': 'blh',
    'fsr': 'fsr',
    'z': 'z',
}

# 3. Creăm fișierul HDF5
with h5py.File('era5_3y.hdf5', 'w') as f:
    f.attrs['version'] = '1.0'
    f.attrs['mode'] = 'training'
    f.attrs['area'] = 'Romania'

    # --- Variabile Dinamice ---
    dyn = f.create_group('dynamic_variables')
#    dyn = f.create_group('dynamic')
    
    for hdf5_name, nc_name in mapping.items():
        # .squeeze() elimină dimensiunile de mărime 1 (ex: plev)
        # .transpose asigură ordinea corectă: (time, lat, lon)
        temp_data = ds[nc_name].squeeze().transpose('time', 'lat', 'lon')
        data = temp_data.values.astype(np.float32)
        
        print(f"Salvare {hdf5_name}: forma finală {data.shape}")
        dyn.create_dataset(hdf5_name, data=data)

    # --- Variabile Statice ---
    stat = f.create_group('static_variables')
#    stat = f.create_group('static')
    for s_var in ['seaMask', 'zOro']:
        # Forțăm forma 2D (lat, lon)
        s_data = ds[s_var].squeeze().values.astype(np.float32)
        if s_data.ndim == 3:
            s_data = s_data[0, :, :] # Luăm doar primul pas de timp dacă e 3D
        
        print(f"Salvare statică {s_var}: forma finală {s_data.shape}")
        stat.create_dataset(s_var, data=s_data)

    # --- Timpul (Format ISO) ---
    times = ds.time.values
    if not np.issubdtype(times.dtype, np.datetime64):
        times = pd.to_datetime(times).values
    
    time_strings = np.array([np.datetime_as_string(t, unit='s') for t in times], dtype='S')
    f.create_dataset('valid_times', data=time_strings)

print("\nSucces! Fișierul 'era5_3y.hdf5' a fost creat corect.")
